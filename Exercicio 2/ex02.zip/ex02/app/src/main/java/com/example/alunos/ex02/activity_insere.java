package com.example.alunos.ex02;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class activity_insere extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insere);
    }
}
